package com.example.miniproyecto3poecincuentazo;

/**
 * Representa los cuatro palos de una baraja de póker estándar de 52 cartas.
 * Cada palo solo aporta información visual (nombre y símbolo); no influye
 * en absoluto en el puntaje de una {@link Carta}, que depende únicamente
 * de su {@link Valor}.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public enum Palo {
    /** Palo de corazones (♥). */
    CORAZONES("Corazones", "♥"),
    /** Palo de diamantes (♦). */
    DIAMANTES("Diamantes", "♦"),
    /** Palo de tréboles (♣). */
    TREBOLES("Tréboles", "♣"),
    /** Palo de picas (♠). */
    PICAS("Picas", "♠");

    private final String nombre;
    private final String simbolo;

    Palo(String nombre, String simbolo) {
        this.nombre = nombre;
        this.simbolo = simbolo;
    }

    /**
     * @return el nombre completo del palo en español (p. ej. {@code "Corazones"}).
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return el símbolo Unicode del palo (p. ej. {@code "♥"}), usado para
     *         mostrar la carta de forma compacta en la interfaz.
     */
    public String getSimbolo() {
        return simbolo;
    }
}
