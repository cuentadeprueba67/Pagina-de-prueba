package com.example.miniproyecto3poecincuentazo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * <b>Resto de la plantilla inicial generada por IntelliJ IDEA, sin usar.</b>
 * Controlador de la demo "Hello JavaFX"; no forma parte del Cincuentazo.
 * Se recomienda eliminarla junto con {@link Launcher} y
 * {@link HelloApplication} antes de la entrega final.
 */
public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}
