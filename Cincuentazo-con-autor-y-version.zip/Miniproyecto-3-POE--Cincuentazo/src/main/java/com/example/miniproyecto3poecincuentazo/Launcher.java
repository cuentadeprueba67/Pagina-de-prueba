package com.example.miniproyecto3poecincuentazo;

import javafx.application.Application;

/**
 * <b>Resto de la plantilla inicial generada por IntelliJ IDEA, sin usar.</b>
 * El punto de entrada real del juego es {@link App}, referenciado como
 * {@code mainClass} en el {@code pom.xml}. Esta clase lanza
 * {@link HelloApplication} (la demo "Hello JavaFX" del asistente de
 * creación de proyectos) y no forma parte del Cincuentazo; se recomienda
 * eliminarla junto con {@link HelloApplication} y {@link HelloController}
 * antes de la entrega final.
 */
public class Launcher {
    public static void main(String[] args) {
        Application.launch(HelloApplication.class, args);
    }
}
