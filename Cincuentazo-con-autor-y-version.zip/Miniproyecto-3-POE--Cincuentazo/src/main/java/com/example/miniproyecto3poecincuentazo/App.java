package com.example.miniproyecto3poecincuentazo;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Punto de entrada real de la aplicación JavaFX (así lo declara el
 * {@code mainClass} configurado en el {@code pom.xml}). Su única
 * responsabilidad es levantar la ventana principal y delegar la navegación
 * entre pantallas a {@link SceneNavigator}; toda la lógica del juego vive
 * en el resto de clases del paquete ({@link Partida}, {@link Mazo}, etc.) y
 * la interacción en los controladores ({@link ConfiguracionController},
 * {@link JuegoController}).
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class App extends Application {

    private static final String VISTA_CONFIGURACION = "/com/example/miniproyecto3poecincuentazo/configuracion.fxml";

    @Override
    public void start(Stage stagePrincipal) {
        SceneNavigator.inicializar(stagePrincipal);
        SceneNavigator.cambiarEscena(VISTA_CONFIGURACION, "Cincuentazo");
        stagePrincipal.show();
    }

    /**
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {
        launch(args);
    }
}
