package com.example.miniproyecto3poecincuentazo;

/**
 * Representa los 13 valores posibles de una carta y los puntos que aporta
 * a la suma de la mesa, de acuerdo con las reglas del Cincuentazo:
 * <ul>
 *     <li>2 al 8 y el 10: suman su propio número.</li>
 *     <li>9: no suma ni resta (aporta 0).</li>
 *     <li>J, Q, K: restan 10.</li>
 *     <li>A: suma 1 o 10, según convenga al jugador.</li>
 * </ul>
 * El As es el único valor con más de un punto posible; por eso
 * {@link #getValoresPosibles()} retorna un arreglo y no un solo entero.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public enum Valor {
    /** Suma 1 o 10 a la mesa, según convenga al jugador. */
    AS("A", new int[]{1, 10}),
    /** Suma 2 a la mesa. */
    DOS("2", new int[]{2}),
    /** Suma 3 a la mesa. */
    TRES("3", new int[]{3}),
    /** Suma 4 a la mesa. */
    CUATRO("4", new int[]{4}),
    /** Suma 5 a la mesa. */
    CINCO("5", new int[]{5}),
    /** Suma 6 a la mesa. */
    SEIS("6", new int[]{6}),
    /** Suma 7 a la mesa. */
    SIETE("7", new int[]{7}),
    /** Suma 8 a la mesa. */
    OCHO("8", new int[]{8}),
    /** No suma ni resta: aporta 0 a la mesa. */
    NUEVE("9", new int[]{0}),
    /** Suma 10 a la mesa. */
    DIEZ("10", new int[]{10}),
    /** Resta 10 a la mesa. */
    JOTA("J", new int[]{-10}),
    /** Resta 10 a la mesa. */
    REINA("Q", new int[]{-10}),
    /** Resta 10 a la mesa. */
    REY("K", new int[]{-10});

    private final String etiqueta;
    private final int[] valoresPosibles;

    Valor(String etiqueta, int[] valoresPosibles) {
        this.etiqueta = etiqueta;
        this.valoresPosibles = valoresPosibles;
    }

    /**
     * @return el texto corto que identifica al valor (p. ej. {@code "A"}, {@code "10"}, {@code "K"}).
     */
    public String getEtiqueta() {
        return etiqueta;
    }

    /**
     * @return una copia del arreglo de puntos que esta carta puede aportar
     *         a la suma de la mesa (más de un elemento solo en el caso del As).
     *         Se devuelve una copia para que el arreglo interno del enum
     *         permanezca inmutable.
     */
    public int[] getValoresPosibles() {
        return valoresPosibles.clone();
    }

    /**
     * @return {@code true} si la carta tiene más de un valor posible
     *         (únicamente el As); {@code false} para el resto de valores.
     */
    public boolean tieneValorAmbiguo() {
        return valoresPosibles.length > 1;
    }
}
