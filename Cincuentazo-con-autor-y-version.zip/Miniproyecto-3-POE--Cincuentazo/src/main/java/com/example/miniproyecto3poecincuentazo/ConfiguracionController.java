package com.example.miniproyecto3poecincuentazo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

/**
 * Controlador de la pantalla inicial ({@code configuracion.fxml}, HU-1):
 * permite elegir el nombre del jugador humano y con cuántos jugadores
 * máquina (1, 2 o 3) se va a jugar, y arranca la partida.
 *
 * <p>El FXML asociado define, entre otros, los siguientes {@code fx:id}:
 * {@code campoNombreJugador}, {@code grupoCantidadMaquinas} (un
 * {@link ToggleGroup} compartido por tres {@link RadioButton}:
 * {@code radioUnaMaquina}, {@code radioDosMaquinas}, {@code radioTresMaquinas}),
 * {@code etiquetaError} y un botón que invoca {@link #manejarIniciarJuego()}.</p>
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class ConfiguracionController {

    private static final String VISTA_JUEGO = "/com/example/miniproyecto3poecincuentazo/juego.fxml";
    private static final String NOMBRE_POR_DEFECTO = "Jugador";

    @FXML private TextField campoNombreJugador;
    @FXML private ToggleGroup grupoCantidadMaquinas;
    @FXML private RadioButton radioUnaMaquina;
    @FXML private RadioButton radioDosMaquinas;
    @FXML private RadioButton radioTresMaquinas;
    @FXML private Label etiquetaError;

    /**
     * Ciclo de vida de JavaFX: se ejecuta automáticamente después de que el
     * FXML inyecta los campos anotados con {@code @FXML}. Deja seleccionada
     * la opción de una sola máquina por defecto.
     */
    @FXML
    private void initialize() {
        etiquetaError.setText("");
        radioUnaMaquina.setSelected(true);
    }

    /**
     * Manejador del botón "Iniciar juego". Crea la {@link Partida} con la
     * configuración elegida, la inicia (HU-2) y navega a la pantalla del
     * juego pasándole la partida ya en curso.
     */
    @FXML
    private void manejarIniciarJuego() {
        etiquetaError.setText("");
        int cantidadMaquinas = obtenerCantidadMaquinasSeleccionada();
        String nombreJugador = obtenerNombreJugador();

        try {
            Partida partida = new Partida(nombreJugador, cantidadMaquinas);
            partida.iniciar();

            JuegoController controlador = SceneNavigator.cambiarEscena(VISTA_JUEGO, "Cincuentazo");
            controlador.iniciarPartida(partida);
        } catch (NumeroJugadoresInvalidoException e) {
            etiquetaError.setText(e.getMessage());
        }
    }

    /**
     * @return 1, 2 o 3 según el radio button seleccionado en {@code grupoCantidadMaquinas}
     */
    private int obtenerCantidadMaquinasSeleccionada() {
        Toggle seleccionado = grupoCantidadMaquinas.getSelectedToggle();
        if (seleccionado == radioDosMaquinas) {
            return 2;
        }
        if (seleccionado == radioTresMaquinas) {
            return 3;
        }
        return 1;
    }

    /**
     * @return el nombre escrito por el usuario, recortado, o
     *         {@value #NOMBRE_POR_DEFECTO} si el campo quedó vacío
     */
    private String obtenerNombreJugador() {
        String nombre = campoNombreJugador.getText();
        if (nombre == null || nombre.isBlank()) {
            return NOMBRE_POR_DEFECTO;
        }
        return nombre.trim();
    }
}
