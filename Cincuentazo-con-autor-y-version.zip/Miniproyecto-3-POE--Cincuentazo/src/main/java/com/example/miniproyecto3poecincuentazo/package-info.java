/**
 * Implementación del mini proyecto #3 del curso 750014C Fundamentos de
 * Programación Orientada a Eventos (2026-1): el juego de cartas
 * "Cincuentazo".
 *
 * <p>El paquete reúne, siguiendo la arquitectura Modelo-Vista-Controlador,
 * las tres capas de la aplicación:</p>
 * <ul>
 *     <li><b>Modelo</b>: {@link com.example.miniproyecto3poecincuentazo.Palo},
 *         {@link com.example.miniproyecto3poecincuentazo.Valor},
 *         {@link com.example.miniproyecto3poecincuentazo.Carta},
 *         {@link com.example.miniproyecto3poecincuentazo.Mazo},
 *         {@link com.example.miniproyecto3poecincuentazo.Jugador} (y sus
 *         subclases {@link com.example.miniproyecto3poecincuentazo.JugadorHumano}
 *         y {@link com.example.miniproyecto3poecincuentazo.JugadorMaquina}),
 *         {@link com.example.miniproyecto3poecincuentazo.Partida} y las
 *         excepciones propias
 *         ({@link com.example.miniproyecto3poecincuentazo.NoHayCartasDisponiblesException},
 *         {@link com.example.miniproyecto3poecincuentazo.CartaInvalidaException},
 *         {@link com.example.miniproyecto3poecincuentazo.NumeroJugadoresInvalidoException}).</li>
 *     <li><b>Vista</b>: los archivos FXML y la hoja de estilos en
 *         {@code src/main/resources/com/example/miniproyecto3poecincuentazo}
 *         ({@code configuracion.fxml}, {@code juego.fxml}, {@code estilos.css}).</li>
 *     <li><b>Controlador</b>: {@link com.example.miniproyecto3poecincuentazo.App}
 *         (arranque de la aplicación), {@link com.example.miniproyecto3poecincuentazo.SceneNavigator}
 *         (navegación entre pantallas),
 *         {@link com.example.miniproyecto3poecincuentazo.ConfiguracionController} y
 *         {@link com.example.miniproyecto3poecincuentazo.JuegoController}.</li>
 * </ul>
 *
 * <p>{@code Launcher}, {@code HelloApplication} y {@code HelloController}
 * son restos de la plantilla inicial de IntelliJ IDEA y no forman parte del
 * juego; el punto de entrada real es
 * {@link com.example.miniproyecto3poecincuentazo.App}.</p>
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
package com.example.miniproyecto3poecincuentazo;
