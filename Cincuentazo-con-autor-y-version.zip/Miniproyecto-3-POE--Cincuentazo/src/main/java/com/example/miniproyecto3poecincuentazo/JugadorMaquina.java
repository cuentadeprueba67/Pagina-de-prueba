package com.example.miniproyecto3poecincuentazo;

import java.util.Comparator;
import java.util.List;

/**
 * Jugador controlado por la máquina. Decide sola qué carta jugar (HU-3); el
 * retraso de 2 a 4 segundos que pide el enunciado antes de aplicar esa
 * decisión se maneja desde el hilo de {@link JuegoController}, no aquí.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class JugadorMaquina extends Jugador {

    /**
     * @param nombre el nombre visible de este jugador máquina
     */
    public JugadorMaquina(String nombre) {
        super(nombre);
    }

    @Override
    public boolean esMaquina() {
        return true;
    }

    /**
     * Estrategia de la IA: entre las cartas jugables, elige la que deje la
     * suma de la mesa más alta posible sin superar 50 (la jugada más
     * "ajustada", que le da más margen a los rivales de quedar bloqueados).
     *
     * @param sumaActual la suma vigente en la mesa
     * @return la carta elegida, o {@code null} si ninguna es jugable
     *         (debería verificarse antes con {@link #tieneJugadaValida(int)})
     */
    public Carta elegirCarta(int sumaActual) {
        List<Carta> manoActual = getMano();
        return manoActual.stream()
                .filter(carta -> carta.esJugable(sumaActual))
                .max(Comparator.comparingInt(carta -> carta.mejorValorPara(sumaActual)))
                .orElse(null);
    }
}
