package com.example.miniproyecto3poecincuentazo;

/**
 * Jugador controlado por la persona frente al computador. Sus decisiones
 * (qué carta jugar y, en el caso del As, qué valor usar) llegan desde la
 * interfaz gráfica a través de {@link JuegoController}, no desde esta clase.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class JugadorHumano extends Jugador {

    /**
     * @param nombre el nombre elegido por el jugador humano
     */
    public JugadorHumano(String nombre) {
        super(nombre);
    }

    @Override
    public boolean esMaquina() {
        return false;
    }
}
