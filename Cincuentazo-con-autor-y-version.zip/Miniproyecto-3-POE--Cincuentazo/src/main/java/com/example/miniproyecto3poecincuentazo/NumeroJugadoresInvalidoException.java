package com.example.miniproyecto3poecincuentazo;

/**
 * Excepción propia y <b>no marcada</b> (unchecked / {@link RuntimeException}):
 * se lanza al construir una {@link Partida} con una cantidad de jugadores
 * máquina fuera del rango permitido por la historia de usuario HU-1 (1, 2 o 3).
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class NumeroJugadoresInvalidoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción de por qué la cantidad de jugadores máquina no es válida
     */
    public NumeroJugadoresInvalidoException(String mensaje) {
        super(mensaje);
    }
}
