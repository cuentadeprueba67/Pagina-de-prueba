package com.example.miniproyecto3poecincuentazo;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Controlador de la pantalla principal del juego ({@code juego.fxml}).
 * Recibe la {@link Partida} ya iniciada desde {@link ConfiguracionController}
 * y se encarga de:
 * <ul>
 *     <li>Renderizar el estado del modelo: suma de la mesa, cartas en el
 *         mazo, carta visible, mano del humano y estado de cada máquina.</li>
 *     <li>Habilitar la interacción del jugador humano (jugar una carta,
 *         incluida la decisión 1/10 del As).</li>
 *     <li>Automatizar el turno de las máquinas (HU-3, HU-4) usando un hilo
 *         en segundo plano que simula el tiempo de reacción de 2 a 4
 *         segundos sin congelar la interfaz.</li>
 *     <li>Verificar y eliminar en vivo al jugador sin jugadas válidas (HU-5).</li>
 *     <li>Llevar un cronómetro de turno en un segundo hilo.</li>
 *     <li>Mostrar el fin del juego con el ganador (HU-6).</li>
 * </ul>
 *
 * <p><b>Hilos usados:</b> esta clase usa exactamente dos hilos, ambos
 * demonio y ambos aplicando sus resultados sobre la interfaz siempre a
 * través de {@link Platform#runLater(Runnable)} para respetar el hilo de
 * JavaFX:</p>
 * <ol>
 *     <li>{@code hilo-turno-maquina}: uno nuevo por cada turno de una
 *         máquina, creado en {@link #iniciarTurnoMaquina()}.</li>
 *     <li>{@code hilo-cronometro}: uno solo, de vida igual a la de la
 *         partida, creado en {@link #iniciarHiloCronometro()}.</li>
 * </ol>
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class JuegoController {

    private static final int ESPERA_MAQUINA_MIN_MS = 2000;

    private static final int ESPERA_MAQUINA_MAX_MS = 4000;

    @FXML private Label labelSumaMesa;
    @FXML private Label labelCartasMazo;
    @FXML private Label labelTurno;
    @FXML private Label labelTiempo;
    @FXML private HBox hboxCartaMesa;
    @FXML private HBox hboxManoHumano;
    @FXML private VBox vboxMaquinas;
    @FXML private Button botonSalir;

    private Partida partida;
    private final List<Label> etiquetasMaquinas = new ArrayList<>();

    private final AtomicInteger segundosTurno = new AtomicInteger(0);
    private volatile boolean juegoActivo = false;
    private Thread hiloCronometro;

    /**
     * Punto de entrada llamado por {@link ConfiguracionController} justo
     * después de crear e iniciar la partida. Arranca el cronómetro y
     * procesa el primer turno.
     *
     * @param partidaIniciada la partida ya preparada (con {@link Partida#iniciar()} ya invocado)
     * @throws NullPointerException si {@code partidaIniciada} es nula
     */
    public void iniciarPartida(Partida partidaIniciada) {
        this.partida = Objects.requireNonNull(partidaIniciada, "La partida no puede ser nula");
        construirEtiquetasMaquinas();
        juegoActivo = true;
        iniciarHiloCronometro();
        procesarTurno();
    }

    /**
     * Crea una {@link Label} por cada jugador máquina de la partida y la
     * agrega al panel lateral, para poder actualizar su estado más adelante
     * en {@link #actualizarEtiquetasMaquinas()}.
     */
    private void construirEtiquetasMaquinas() {
        vboxMaquinas.getChildren().clear();
        etiquetasMaquinas.clear();
        for (Jugador jugador : partida.getJugadores()) {
            if (jugador.esMaquina()) {
                Label etiqueta = new Label();
                etiquetasMaquinas.add(etiqueta);
                vboxMaquinas.getChildren().add(etiqueta);
            }
        }
    }

    // ------------------------------------------------------------------
    // Flujo de turnos
    // ------------------------------------------------------------------

    /**
     * Motor del turno: primero descarta (elimina) en cadena a todos los
     * jugadores consecutivos que no tengan jugada válida (HU-5). Si con eso
     * termina la partida, muestra el resultado; si no, prepara la interfaz
     * para el jugador que sí puede jugar (habilita la mano si es el humano,
     * o dispara el hilo de la máquina si le toca a ella).
     */
    private void procesarTurno() {
        while (!partida.isTerminada() && partida.verificarYEliminarSiNoPuedeJugar()) {
            // El jugador actual no tenía jugada válida: ya quedó eliminado y
            // Partida avanzó el turno internamente. Seguimos revisando al
            // siguiente por si tampoco puede jugar.
        }

        actualizarVista();

        if (partida.isTerminada()) {
            finalizarJuego();
            return;
        }

        segundosTurno.set(0);
        labelTiempo.setText("Tiempo de turno: 0s");

        if (partida.getJugadorActual().esMaquina()) {
            iniciarTurnoMaquina();
        }
        // Si le toca al humano no hay que hacer nada más: actualizarVista() ya
        // dejó habilitados, en actualizarManoHumano(), los botones de las
        // cartas jugables.
    }

    /**
     * Hilo 1 ({@code hilo-turno-maquina}): espera entre 2 y 4 segundos (tal
     * como pide HU-3/HU-4 para simular el "pensar" de la máquina) sin
     * bloquear el hilo de JavaFX, y luego aplica la jugada de vuelta en el
     * hilo de la interfaz mediante {@link Platform#runLater(Runnable)}.
     */
    private void iniciarTurnoMaquina() {
        Thread hiloTurnoMaquina = new Thread(() -> {
            int esperaMs = ThreadLocalRandom.current().nextInt(ESPERA_MAQUINA_MIN_MS, ESPERA_MAQUINA_MAX_MS + 1);
            try {
                Thread.sleep(esperaMs);
            } catch (InterruptedException interrumpido) {
                Thread.currentThread().interrupt();
                return;
            }
            Platform.runLater(this::ejecutarJugadaMaquina);
        }, "hilo-turno-maquina");
        hiloTurnoMaquina.setDaemon(true);
        hiloTurnoMaquina.start();
    }

    /**
     * Aplica la jugada elegida por la IA de la máquina en turno y continúa
     * el flujo del juego. Se ejecuta siempre en el hilo de JavaFX (invocado
     * vía {@code Platform.runLater} desde {@link #iniciarTurnoMaquina()}).
     */
    private void ejecutarJugadaMaquina() {
        if (!juegoActivo || partida.isTerminada()) {
            return;
        }
        Jugador actual = partida.getJugadorActual();
        if (!actual.esMaquina()) {
            // Resguardo defensivo: no debería pasar, el turno no cambia mientras
            // el hilo espera porque solo el hilo de JavaFX toca la partida.
            procesarTurno();
            return;
        }
        JugadorMaquina maquina = (JugadorMaquina) actual;
        Carta elegida = maquina.elegirCarta(partida.getSumaMesa());
        if (elegida == null) {
            // También defensivo: procesarTurno() ya filtró a los jugadores sin
            // jugada válida antes de llegar aquí.
            partida.verificarYEliminarSiNoPuedeJugar();
        } else {
            partida.jugarCartaJugadorActual(elegida, null);
        }
        procesarTurno();
    }

    /**
     * Manejador de clic sobre una de las cartas de la mano del humano.
     * Resuelve el valor a aplicar (preguntando por diálogo si la carta es
     * un As con más de una opción válida), delega la jugada en
     * {@link Partida} y continúa el flujo de turnos.
     *
     * @param carta la carta que el jugador humano hizo clic para jugar
     */
    private void manejarClickCartaHumano(Carta carta) {
        if (partida.isTerminada() || partida.getJugadorActual().esMaquina()) {
            return;
        }

        Integer valorElegido = resolverValorHumano(carta);
        if (valorElegido == null && carta.getValor().tieneValorAmbiguo() && !carta.esJugable(partida.getSumaMesa())) {
            // El As no tiene ningún valor válido; no debería ocurrir porque el
            // botón estaría deshabilitado, pero se deja como resguardo.
            mostrarAlerta(Alert.AlertType.WARNING, "Jugada inválida",
                    "Esa carta excede la suma máxima de 50 con la suma actual de la mesa.");
            return;
        }

        try {
            partida.jugarCartaJugadorActual(carta, valorElegido);
        } catch (CartaInvalidaException error) {
            mostrarAlerta(Alert.AlertType.WARNING, "Jugada inválida", error.getMessage());
            return;
        }
        procesarTurno();
    }

    /**
     * Determina el valor a aplicar cuando el humano juega una carta: para
     * cartas sin ambigüedad retorna {@code null} (Partida decide sola); para
     * un As con una sola opción válida la retorna directamente; y para un As
     * con ambas opciones (1 y 10) válidas, le pregunta al jugador con
     * {@link #preguntarValorAs()}.
     *
     * @param carta la carta que el humano va a jugar
     * @return el valor elegido, o {@code null} si no aplica o no hay ninguna opción válida
     */
    private Integer resolverValorHumano(Carta carta) {
        if (!carta.getValor().tieneValorAmbiguo()) {
            return null;
        }
        int sumaActual = partida.getSumaMesa();
        List<Integer> opcionesValidas = new ArrayList<>();
        for (int posible : carta.getValoresPosibles()) {
            if (sumaActual + posible <= Partida.SUMA_MAXIMA) {
                opcionesValidas.add(posible);
            }
        }
        if (opcionesValidas.isEmpty()) {
            return null;
        }
        if (opcionesValidas.size() == 1) {
            return opcionesValidas.get(0);
        }
        return preguntarValorAs();
    }

    /**
     * Muestra un diálogo para que el humano elija si el As jugado suma 1 o
     * 10 a la mesa ("según convenga", tal como indica el enunciado).
     *
     * @return 1 o 10, según el botón que el jugador haya elegido (1 por
     *         defecto si cierra el diálogo sin elegir)
     */
    private Integer preguntarValorAs() {
        Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
        dialogo.setTitle("As");
        dialogo.setHeaderText("¿Cómo quieres jugar el As?");
        dialogo.setContentText("Elige el valor que se sumará a la mesa.");

        ButtonType botonUno = new ButtonType("Sumar 1");
        ButtonType botonDiez = new ButtonType("Sumar 10");
        dialogo.getButtonTypes().setAll(botonUno, botonDiez);

        Optional<ButtonType> resultado = dialogo.showAndWait();
        return (resultado.isPresent() && resultado.get() == botonDiez) ? 10 : 1;
    }

    /**
     * Cierra la partida (HU-6): detiene el cronómetro, deshabilita la mano
     * del humano y muestra el ganador (o la ausencia de uno) tanto en la
     * barra superior como en un diálogo emergente.
     */
    private void finalizarJuego() {
        juegoActivo = false;
        detenerHiloCronometro();
        deshabilitarManoHumano();

        Jugador ganador = partida.getGanador();
        String mensaje = ganador != null
                ? "¡" + ganador.getNombre() + " ha ganado la partida!"
                : "La partida terminó sin un jugador restante.";
        labelTurno.setText(mensaje);
        mostrarAlerta(Alert.AlertType.INFORMATION, "Fin del juego", mensaje);
    }

    /**
     * Muestra un {@link Alert} simple con el tipo, título y mensaje indicados.
     */
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    /**
     * Deshabilita todos los botones de la mano del humano (usado al
     * terminar la partida).
     */
    private void deshabilitarManoHumano() {
        for (var nodo : hboxManoHumano.getChildren()) {
            nodo.setDisable(true);
        }
    }

    // ------------------------------------------------------------------
    // Cronómetro (segundo hilo)
    // ------------------------------------------------------------------

    /**
     * Hilo 2 ({@code hilo-cronometro}): corre durante toda la partida,
     * incrementando cada segundo el contador de tiempo del turno actual y
     * reflejándolo en {@code labelTiempo} a través de
     * {@link Platform#runLater(Runnable)}. Se detiene con
     * {@link #detenerHiloCronometro()}.
     */
    private void iniciarHiloCronometro() {
        hiloCronometro = new Thread(() -> {
            while (juegoActivo) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException interrumpido) {
                    Thread.currentThread().interrupt();
                    return;
                }
                if (!juegoActivo) {
                    return;
                }
                int segundos = segundosTurno.incrementAndGet();
                Platform.runLater(() -> labelTiempo.setText("Tiempo de turno: " + segundos + "s"));
            }
        }, "hilo-cronometro");
        hiloCronometro.setDaemon(true);
        hiloCronometro.start();
    }

    /**
     * Detiene el hilo del cronómetro (interrumpiéndolo si está dormido).
     */
    private void detenerHiloCronometro() {
        if (hiloCronometro != null) {
            hiloCronometro.interrupt();
        }
    }

    // ------------------------------------------------------------------
    // Renderizado del estado del modelo
    // ------------------------------------------------------------------

    /**
     * Refresca todos los elementos visuales con el estado actual del
     * modelo: suma de la mesa, cartas en el mazo, turno, carta visible en
     * la mesa, mano del humano y estado de cada máquina. Debe llamarse
     * siempre desde el hilo de JavaFX.
     */
    void actualizarVista() {
        labelSumaMesa.setText("Suma en mesa: " + partida.getSumaMesa() + " / " + Partida.SUMA_MAXIMA);
        labelCartasMazo.setText("Cartas en el mazo: " + partida.getCartasEnMazo());
        labelTurno.setText(partida.isTerminada()
                ? "Juego terminado"
                : "Turno de: " + partida.getJugadorActual().getNombre());

        actualizarCartaEnMesa();
        actualizarManoHumano();
        actualizarEtiquetasMaquinas();
    }

    /**
     * Muestra en {@code hboxCartaMesa} la última carta jugada (la visible
     * actualmente en la mesa).
     */
    private void actualizarCartaEnMesa() {
        hboxCartaMesa.getChildren().clear();
        List<Carta> mesa = partida.getMesa();
        if (!mesa.isEmpty()) {
            Carta ultima = mesa.get(mesa.size() - 1);
            Label etiquetaCarta = new Label(ultima.toString());
            etiquetaCarta.getStyleClass().add("carta");
            hboxCartaMesa.getChildren().add(etiquetaCarta);
        }
    }

    /**
     * Reconstruye los botones de la mano del humano: uno por carta, cada
     * uno habilitado solo si es el turno del humano y esa carta es jugable
     * con la suma actual, y conectado a {@link #manejarClickCartaHumano(Carta)}.
     */
    private void actualizarManoHumano() {
        hboxManoHumano.getChildren().clear();
        Jugador humano = partida.getJugadores().get(0);
        boolean esTurnoHumano = !partida.isTerminada() && partida.getJugadorActual() == humano;

        for (Carta carta : humano.getMano()) {
            Button boton = new Button(carta.toString());
            boton.getStyleClass().add("carta-boton");
            boolean jugable = esTurnoHumano && carta.esJugable(partida.getSumaMesa());
            boton.setDisable(!jugable);
            boton.setOnAction(evento -> manejarClickCartaHumano(carta));
            hboxManoHumano.getChildren().add(boton);
        }
    }

    /**
     * Actualiza el texto de cada etiqueta del panel de máquinas con su
     * nombre y, según corresponda, su cantidad de cartas o "eliminado".
     */
    private void actualizarEtiquetasMaquinas() {
        List<Jugador> jugadores = partida.getJugadores();
        int indiceMaquina = 0;
        for (Jugador jugador : jugadores) {
            if (!jugador.esMaquina()) {
                continue;
            }
            Label etiqueta = etiquetasMaquinas.get(indiceMaquina++);
            String estado = jugador.isEliminado()
                    ? "eliminado"
                    : jugador.cantidadCartas() + " cartas";
            etiqueta.setText(jugador.getNombre() + ": " + estado);
        }
    }

    /**
     * Manejador del botón "Salir": detiene el cronómetro y cierra la aplicación.
     */
    @FXML
    private void manejarSalir() {
        juegoActivo = false;
        detenerHiloCronometro();
        Platform.exit();
    }
}
