package com.example.miniproyecto3poecincuentazo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Representa a un jugador de la partida (humano o máquina). Mantiene su
 * mano de cartas y su estado (activo o eliminado). Es la clase base de
 * {@link JugadorHumano} y {@link JugadorMaquina}.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public abstract class Jugador {

    /** Nombre visible del jugador. */
    protected final String nombre;
    /** Cartas que el jugador tiene actualmente en la mano. */
    protected final List<Carta> mano;
    /** {@code true} una vez que el jugador quedó eliminado de la partida. */
    protected boolean eliminado;

    /**
     * @param nombre el nombre visible del jugador, no puede ser nulo
     * @throws NullPointerException si {@code nombre} es nulo
     */
    protected Jugador(String nombre) {
        this.nombre = Objects.requireNonNull(nombre, "El nombre no puede ser nulo");
        this.mano = new ArrayList<>(4);
        this.eliminado = false;
    }

    /**
     * @return el nombre visible de este jugador
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return una vista de solo lectura de la mano actual del jugador.
     */
    public List<Carta> getMano() {
        return Collections.unmodifiableList(mano);
    }

    /**
     * @return la cantidad de cartas que el jugador tiene actualmente en la mano.
     */
    public int cantidadCartas() {
        return mano.size();
    }

    /**
     * @return {@code true} si el jugador ya fue eliminado de la partida.
     */
    public boolean isEliminado() {
        return eliminado;
    }

    /**
     * Marca al jugador como eliminado (HU-5). No decide qué pasa con sus
     * cartas; eso lo resuelve quien orquesta la partida llamando a
     * {@link #vaciarMano()}.
     */
    public void eliminar() {
        this.eliminado = true;
    }

    /**
     * Agrega una carta a la mano del jugador (por ejemplo, al repartir o al
     * tomar del mazo después de jugar).
     *
     * @param carta la carta a agregar, no puede ser nula
     * @throws NullPointerException si {@code carta} es nula
     */
    public void recibirCarta(Carta carta) {
        Objects.requireNonNull(carta, "La carta no puede ser nula");
        mano.add(carta);
    }

    /**
     * Remueve y retorna una carta de la mano del jugador.
     *
     * @param carta la carta que se desea jugar
     * @return la misma carta recibida, ya removida de la mano
     * @throws CartaInvalidaException si la carta no está en la mano
     */
    public Carta jugarCarta(Carta carta) {
        if (!mano.remove(carta)) {
            throw new CartaInvalidaException(
                    nombre + " no tiene la carta " + carta + " en su mano.");
        }
        return carta;
    }

    /**
     * Vacía por completo la mano del jugador y retorna las cartas que tenía.
     * Se usa al eliminar a un jugador, para poder enviar esas cartas de
     * vuelta al mazo (HU-5).
     *
     * @return las cartas que el jugador tenía en la mano antes de vaciarla
     */
    public List<Carta> vaciarMano() {
        List<Carta> cartas = new ArrayList<>(mano);
        mano.clear();
        return cartas;
    }

    /**
     * @param sumaActual la suma vigente en la mesa
     * @return {@code true} si existe al menos una carta en la mano jugable
     *         sin exceder 50 (regla principal)
     */
    public boolean tieneJugadaValida(int sumaActual) {
        for (Carta carta : mano) {
            if (carta.esJugable(sumaActual)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return {@code true} si este jugador es controlado por la máquina.
     */
    public abstract boolean esMaquina();
}
