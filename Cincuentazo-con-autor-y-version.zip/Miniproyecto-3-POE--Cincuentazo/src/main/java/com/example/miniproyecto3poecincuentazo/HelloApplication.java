package com.example.miniproyecto3poecincuentazo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * <b>Resto de la plantilla inicial generada por IntelliJ IDEA, sin usar.</b>
 * No es el punto de entrada del juego (ese es {@link App}); se recomienda
 * eliminarla junto con {@link Launcher} y {@link HelloController} antes de
 * la entrega final.
 */
public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("configuracion.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
}
