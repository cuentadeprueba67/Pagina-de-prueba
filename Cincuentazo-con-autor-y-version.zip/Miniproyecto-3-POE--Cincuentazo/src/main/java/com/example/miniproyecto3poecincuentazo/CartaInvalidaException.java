package com.example.miniproyecto3poecincuentazo;

/**
 * Excepción propia y <b>no marcada</b> (unchecked / {@link RuntimeException}):
 * se lanza cuando se intenta jugar una carta que no está en la mano del
 * jugador, o cuyo valor haría que la suma de la mesa superara 50. Al ser un
 * error de uso de la API del modelo (no una condición externa recuperable),
 * no se obliga a declararla ni capturarla.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class CartaInvalidaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción de por qué la carta o el valor elegido no es válido
     */
    public CartaInvalidaException(String mensaje) {
        super(mensaje);
    }
}
