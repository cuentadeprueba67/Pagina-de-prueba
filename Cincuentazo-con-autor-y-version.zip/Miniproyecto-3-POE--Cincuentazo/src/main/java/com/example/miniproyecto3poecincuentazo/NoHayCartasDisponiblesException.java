package com.example.miniproyecto3poecincuentazo;

/**
 * Excepción propia y <b>marcada</b> (checked): se lanza cuando se intenta
 * tomar una carta del mazo y no hay ninguna disponible, ni siquiera
 * reciclando las cartas jugadas en la mesa. En condiciones normales del
 * juego no debería ocurrir, pero el compilador obliga a declararla o
 * capturarla explícitamente, lo cual documenta esa situación límite.
 *
 * @author Juan Diego Quiñones
 * @author Jeferson Gomez Gomez
 * @version 1.0
 */
public class NoHayCartasDisponiblesException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción del motivo por el cual no hay cartas disponibles
     */
    public NoHayCartasDisponiblesException(String mensaje) {
        super(mensaje);
    }

    /**
     * @param mensaje descripción del motivo por el cual no hay cartas disponibles
     * @param causa   la excepción original que originó este error, si aplica
     */
    public NoHayCartasDisponiblesException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
